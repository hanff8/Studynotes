## 1. vscode
```shell

#设置代理
go env -w GOPROXY=https://goproxy.io,direct

#设置gopath
go env -w GOPATH=D:\MyDevEnv\go

#设置goroot
go env -w GOROOT=D:\MyDevEnv\go

#开启gomod支持
go env -w GO111MODULE=on
```