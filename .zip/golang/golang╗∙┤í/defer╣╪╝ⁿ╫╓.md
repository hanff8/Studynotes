1. 相当于java中的finally
2. 