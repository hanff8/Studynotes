[参考](https://felixc.at/2016/05/a-brief-introduction-to-pacman-hooks/)
	