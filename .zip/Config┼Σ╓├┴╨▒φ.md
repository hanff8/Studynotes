
## [[scoop 相关]]

## [[代理相关#switchOmega 代理]]

## [[Ubuntu&&wsl相关配置]]

## [[WSL2 & ArchLinux via lxrunoffline]]

## [[git 配置问题]]

