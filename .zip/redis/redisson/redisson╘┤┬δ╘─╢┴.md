## 1. 流程图
#trylock
获取锁

![[Pasted image 20230614165628.png]]
## 2. 一些参数
- watchDogTimeOut：默认时间30*1000，及30s钟