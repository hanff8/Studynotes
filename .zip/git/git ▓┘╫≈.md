## 1. Tag

```shell
# 查看tag列表
git tag -l

# 切换到指定tag
git checkout tag_name

# 切换到指定tag,并创建分支
git checkout -b branch_name tag_name
```


#git 