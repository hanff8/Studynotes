```groovy
// 阿里云 https://developer.aliyun.com/article/754038
buildscript{
	repository{
		maven{ url 'https://maven.aliyun.com/repository/jcenter'}  
		maven{ url 'https://maven.aliyun.com/repository/gradle-plugin'}  
		maven{ url 'https://maven.aliyun.com/repository/spring-plugin'}  
		maven{ url 'https://maven.aliyun.com/repository/central'}  
		maven{ url 'https://maven.aliyun.com/repository/spring'}  
		maven{ url 'https://maven.aliyun.com/repository/grail-core'}  
		maven{ url 'https://maven.aliyun.com/repository/apache-snapshots'}  
		maven{ url 'https://maven.aliyun.com/repository/public'}  
		maven{ url 'https://maven.aliyun.com/repository/google'}
	}
}

```