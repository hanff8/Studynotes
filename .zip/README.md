# Study-notes
study-notes record by obsidian
