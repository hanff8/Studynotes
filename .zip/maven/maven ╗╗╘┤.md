	更换阿里云镜像
```xml
<mirror>
  <id>alimaven</id>
  <mirrorOf>central</mirrorOf>  
  <name>aliyun maven</name>
  <url>http://maven.aliyun.com/nexus/content/groups/public/</url>      
</mirror>
```







#maven
