[maven之自定义archetype - 吴振照 - 博客园 (cnblogs.com)](https://www.cnblogs.com/wuzhenzhao/p/13307436.html)
